﻿namespace Take_Home
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_word1 = new System.Windows.Forms.Label();
            this.lbl_word2 = new System.Windows.Forms.Label();
            this.lbl_word3 = new System.Windows.Forms.Label();
            this.lbl_word4 = new System.Windows.Forms.Label();
            this.lbl_word5 = new System.Windows.Forms.Label();
            this.btn_play = new System.Windows.Forms.Button();
            this.tb_word1 = new System.Windows.Forms.TextBox();
            this.tb_word2 = new System.Windows.Forms.TextBox();
            this.tb_word3 = new System.Windows.Forms.TextBox();
            this.tb_word4 = new System.Windows.Forms.TextBox();
            this.tb_word5 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_word1
            // 
            this.lbl_word1.Font = new System.Drawing.Font("Sylfaen", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_word1.Location = new System.Drawing.Point(37, 58);
            this.lbl_word1.Name = "lbl_word1";
            this.lbl_word1.Size = new System.Drawing.Size(127, 32);
            this.lbl_word1.TabIndex = 0;
            this.lbl_word1.Text = "Word 1 :";
            // 
            // lbl_word2
            // 
            this.lbl_word2.AutoSize = true;
            this.lbl_word2.Font = new System.Drawing.Font("Sylfaen", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_word2.Location = new System.Drawing.Point(37, 110);
            this.lbl_word2.Name = "lbl_word2";
            this.lbl_word2.Size = new System.Drawing.Size(95, 26);
            this.lbl_word2.TabIndex = 1;
            this.lbl_word2.Text = "Word 2 :";
            // 
            // lbl_word3
            // 
            this.lbl_word3.AutoSize = true;
            this.lbl_word3.Font = new System.Drawing.Font("Sylfaen", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_word3.Location = new System.Drawing.Point(37, 159);
            this.lbl_word3.Name = "lbl_word3";
            this.lbl_word3.Size = new System.Drawing.Size(95, 26);
            this.lbl_word3.TabIndex = 2;
            this.lbl_word3.Text = "Word 3 :";
            // 
            // lbl_word4
            // 
            this.lbl_word4.AutoSize = true;
            this.lbl_word4.Font = new System.Drawing.Font("Sylfaen", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_word4.Location = new System.Drawing.Point(37, 207);
            this.lbl_word4.Name = "lbl_word4";
            this.lbl_word4.Size = new System.Drawing.Size(101, 26);
            this.lbl_word4.TabIndex = 3;
            this.lbl_word4.Text = "Word 4 : ";
            // 
            // lbl_word5
            // 
            this.lbl_word5.AutoSize = true;
            this.lbl_word5.Font = new System.Drawing.Font("Sylfaen", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_word5.Location = new System.Drawing.Point(37, 256);
            this.lbl_word5.Name = "lbl_word5";
            this.lbl_word5.Size = new System.Drawing.Size(95, 26);
            this.lbl_word5.TabIndex = 4;
            this.lbl_word5.Text = "Word 5 :";
            // 
            // btn_play
            // 
            this.btn_play.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_play.Location = new System.Drawing.Point(175, 309);
            this.btn_play.Name = "btn_play";
            this.btn_play.Size = new System.Drawing.Size(110, 46);
            this.btn_play.TabIndex = 5;
            this.btn_play.Text = "PLAY";
            this.btn_play.UseVisualStyleBackColor = true;
            this.btn_play.Click += new System.EventHandler(this.btn_play_click);
            // 
            // tb_word1
            // 
            this.tb_word1.Location = new System.Drawing.Point(147, 60);
            this.tb_word1.Name = "tb_word1";
            this.tb_word1.Size = new System.Drawing.Size(186, 26);
            this.tb_word1.TabIndex = 6;
            // 
            // tb_word2
            // 
            this.tb_word2.Location = new System.Drawing.Point(147, 110);
            this.tb_word2.Name = "tb_word2";
            this.tb_word2.Size = new System.Drawing.Size(186, 26);
            this.tb_word2.TabIndex = 7;
            // 
            // tb_word3
            // 
            this.tb_word3.Location = new System.Drawing.Point(147, 159);
            this.tb_word3.Name = "tb_word3";
            this.tb_word3.Size = new System.Drawing.Size(186, 26);
            this.tb_word3.TabIndex = 8;
            // 
            // tb_word4
            // 
            this.tb_word4.Location = new System.Drawing.Point(147, 208);
            this.tb_word4.Name = "tb_word4";
            this.tb_word4.Size = new System.Drawing.Size(186, 26);
            this.tb_word4.TabIndex = 9;
            // 
            // tb_word5
            // 
            this.tb_word5.Location = new System.Drawing.Point(147, 256);
            this.tb_word5.Name = "tb_word5";
            this.tb_word5.Size = new System.Drawing.Size(186, 26);
            this.tb_word5.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tb_word5);
            this.Controls.Add(this.tb_word4);
            this.Controls.Add(this.tb_word3);
            this.Controls.Add(this.tb_word2);
            this.Controls.Add(this.tb_word1);
            this.Controls.Add(this.btn_play);
            this.Controls.Add(this.lbl_word5);
            this.Controls.Add(this.lbl_word4);
            this.Controls.Add(this.lbl_word3);
            this.Controls.Add(this.lbl_word2);
            this.Controls.Add(this.lbl_word1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_word1;
        private System.Windows.Forms.Label lbl_word2;
        private System.Windows.Forms.Label lbl_word3;
        private System.Windows.Forms.Label lbl_word4;
        private System.Windows.Forms.Label lbl_word5;
        private System.Windows.Forms.Button btn_play;
        private System.Windows.Forms.TextBox tb_word1;
        private System.Windows.Forms.TextBox tb_word2;
        private System.Windows.Forms.TextBox tb_word3;
        private System.Windows.Forms.TextBox tb_word4;
        private System.Windows.Forms.TextBox tb_word5;
    }
}

