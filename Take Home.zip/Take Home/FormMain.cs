﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Take_Home
{
    public partial class FormMain : Form
    {
        private string [] words;

        public FormMain(string[] wordsFromForm1)
        {
            InitializeComponent();
            //this.KeyPreview = true;
            //this.KeyPress += new KeyPressEventHandler(kp_q);
            words = wordsFromForm1;
            Random rnd = new Random();
            int index = rnd.Next(0, words.Length);
            lbl_randomWord.Text = words[index];
        }

        private void metodd(char huruf, string huruftext)
        {
            string randomword = Convert.ToString(lbl_randomWord.Text);
            char[] arrayHuruf = randomword.ToCharArray();
            if (arrayHuruf[0] == huruf)
            {
                lbl_Jawaban1.Text = huruftext;
            }
            if (arrayHuruf[1] == huruf)
            {
                lbl_Jawaban2.Text = huruftext;
            }
            if (arrayHuruf[2] == huruf)
            {
                lbl_Jawaban3.Text = huruftext;
            }
            if (arrayHuruf[3] == huruf)
            {
                lbl_Jawaban4.Text = huruftext;
            }
            if (arrayHuruf[4] == huruf)
            {
                lbl_Jawaban5.Text = huruftext;
            }
            if (lbl_Jawaban1.Text != "_" && lbl_Jawaban2.Text != "_" && lbl_Jawaban3.Text != "_" && lbl_Jawaban4.Text != "_" && lbl_Jawaban5.Text != "_")
            {
                MessageBox.Show("You win");
            }
        }

        private void kp_q(object sender, KeyPressEventArgs e)
        {
            //string randomword = Convert.ToString(lbl_randomWord.Text);
            //char[] arrayHuruf = randomword.ToCharArray();

            //for (int i = 0; i < arrayHuruf.Length; i++)
            //{
            //    if (arrayHuruf[0] == e.KeyChar)
            //    {
            //        lbl_Jawaban1.Text = e.KeyChar.ToString();
            //    }
            //    if (arrayHuruf[1] == e.KeyChar)
            //    {
            //        lbl_Jawaban2.Text = e.KeyChar.ToString();
            //    }
            //    if (arrayHuruf[2] == e.KeyChar)
            //    {
            //        lbl_Jawaban3.Text = e.KeyChar.ToString();
            //    }
            //    if (arrayHuruf[3] == e.KeyChar)
            //    {
            //        lbl_Jawaban4.Text = e.KeyChar.ToString();
            //    }
            //    if (arrayHuruf[4] == e.KeyChar)
            //    {
            //        lbl_Jawaban5.Text = e.KeyChar.ToString();
            //    }
            //}
            //if (lbl_Jawaban1.Text != "_" && lbl_Jawaban2.Text != "_" && lbl_Jawaban3.Text != "_" && lbl_Jawaban4.Text != "_" && lbl_Jawaban5.Text != "_"  )
            //{
            //    MessageBox.Show("You win");
            //}
        }

        private void btn_q_click(object sender, EventArgs e)
        {
            metodd('q',"q");
        }

        private void btn_w_click(object sender, EventArgs e)
        {
            metodd('w', "w");
        }

        private void btn_e_click(object sender, EventArgs e)
        {
            metodd('e', "e");
        }

        private void btn_r_click(object sender, EventArgs e)
        {
            metodd('r', "r");
        }

        private void btn_t_click(object sender, EventArgs e)
        {
            metodd('t', "t");
        }

        private void btn_y_click(object sender, EventArgs e)
        {
            metodd('y', "y");
        }

        private void btn_u_click(object sender, EventArgs e)
        {
            metodd('u', "u");
        }

        private void btn_i_click(object sender, EventArgs e)
        {
            metodd('i', "i");
        }

        private void btn_o_click(object sender, EventArgs e)
        {
            metodd('o', "o");
        }

        private void btn_p_click(object sender, EventArgs e)
        {
            metodd('p', "p");
        }

        private void btn_a_click(object sender, EventArgs e)
        {
            metodd('a', "a");
        }

        private void btn_s_click(object sender, EventArgs e)
        {
            metodd('s', "s");
        }

        private void btn_d_click(object sender, EventArgs e)
        {
            metodd('d', "d");
        }

        private void btn_f_click(object sender, EventArgs e)
        {
            metodd('f', "f");
        }

        private void btn_g_click(object sender, EventArgs e)
        {
            metodd('g', "g");
        }

        private void btn_h_click(object sender, EventArgs e)
        {
            metodd('h', "h");
        }

        private void btn_j_click(object sender, EventArgs e)
        {
            metodd('j', "j");
        }

        private void btn_k_click(object sender, EventArgs e)
        {
            metodd('k', "k");
        }

        private void btn_l_click(object sender, EventArgs e)
        {
            metodd('l', "l");
        }

        private void btn_z_click(object sender, EventArgs e)
        {
            metodd('z', "z");
        }

        private void btn_x_click(object sender, EventArgs e)
        {
            metodd('x', "x");
        }

        private void btn_c_click(object sender, EventArgs e)
        {
            metodd('c', "c");
        }

        private void btn_v_click(object sender, EventArgs e)
        {
            metodd('v', "v");
        }

        private void btn_b_click(object sender, EventArgs e)
        {
            metodd('b', "b");
        }

        private void btn_n_click(object sender, EventArgs e)
        {
            metodd('n', "n");
        }

        private void btn_m_click(object sender, EventArgs e)
        {
            metodd('m', "m");
        }
    }
}
