﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Take_Home
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_play_click(object sender, EventArgs e)
        {
            string[] words = new string[6];
            words[1] = Convert.ToString(tb_word1.Text);
            words[2] = Convert.ToString(tb_word2.Text);
            words[3] = Convert.ToString(tb_word3.Text);
            words[4] = Convert.ToString(tb_word4.Text);
            words[5] = Convert.ToString(tb_word5.Text);

            if ((Cekangka(words[1])) || (Cekangka(words[2])) || (Cekangka(words[3])) || (Cekangka(words[4])) || (Cekangka(words[5])))
            {
                MessageBox.Show("Eror");
            }
            else if (words[1].Length == 5 && words[2].Length == 5 && words[3].Length == 5 && words[4].Length == 5 && words[5].Length == 5 &
                words[1] != words[2] & words[1] != words[3] & words[1] != words[4] & words[1] != words[5] & words[2] != words[3] & words[2] != words[4] &
                 words[2] != words[5] & words[3] != words[4] & words[3] != words[5] & words[4] != words[5])
            {
                FormMain formMain = new FormMain(words);
                formMain.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Eror");
            }
        }

        static bool Cekangka(string input)
        {
            foreach (char a in input)
            {
                if (char.IsDigit(a))
                {
                    return true;
                }
            }
            return false;
        }
    }
}